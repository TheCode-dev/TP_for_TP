﻿namespace TP_KP_Belyshev.Models
{
	public class ApplicationRoleEntity
	{
		public int ID { get; set; }
		public string Name { get; set; }
		public string Role { get; set; }
	}
}
