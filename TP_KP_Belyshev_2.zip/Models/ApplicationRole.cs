﻿using Microsoft.AspNetCore.Identity;

namespace TP_KP_Belyshev.Models
{
	public class ApplicationRole : IdentityRole<int>
	{
	}
}
