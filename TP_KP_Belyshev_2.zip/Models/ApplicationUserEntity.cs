﻿namespace TP_KP_Belyshev.Models
{
	public class ApplicationUserEntity
	{
		public int ID { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Email { get; set; }

	}
}
