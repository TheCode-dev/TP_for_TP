﻿namespace TP_KP_Belyshev.Repositories
{
	public class BaseRepository
	{
		protected string GetConnectionString
			=> "Server=81.4.243.184;Database=kp_belyshev;Uid=root;Pwd=qwerty_33;";
	}
}
